﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW13_Orbit
{
    public partial class Form1 : Form
    {
        private int x = 50;
        private int y = 50;
        double centerX = 95;
        double centerY = 95;
        int radius = 50;
        double angleStep = .01;
        double twoPI = 2 * Math.PI;
        double currentAngle = 0;




        public Form1()
        {            
            InitializeComponent();
        }
       
        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (checkBoxCG.Checked == true)
            {
                SolidBrush sb = new SolidBrush(Color.Gray);
                SolidBrush sb1 = new SolidBrush(Color.Red);
                Graphics g = pictureBox1.CreateGraphics();

                g.FillEllipse(sb, e.X, e.Y, 70, 70);
                g.FillEllipse(sb1, e.X + 30, e.Y + 30, 10, 10);
            }
            
            else
            {
                SolidBrush sb = new SolidBrush(Color.Green);
                SolidBrush sb1 = new SolidBrush(Color.Red);
                Graphics g = pictureBox1.CreateGraphics();

                g.FillEllipse(sb1, x, y, 10, 10);
            }             
        }       
        private void MovingTick(object sender, EventArgs e)
        {

            currentAngle -= angleStep;
            x = (int)(centerX + Math.Cos(currentAngle * twoPI) * radius);
            y = (int)(centerY + Math.Sin(currentAngle * twoPI) * radius);

            Invalidate();            
            
        }
      
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.FillRectangle(Brushes.BlueViolet, x, y, 100, 100);
            e.Graphics.FillRectangle(Brushes.Red, x+45, y+45, 10, 10);
        }
        
    }
}
