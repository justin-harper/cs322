﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Spreadsheet
{
    public class Spreadsheet
    {
        /************************************************************************
         *                      CellChild class decleration
         ************************************************************************/
        public class CellChild : Cell
        {
            //create inherited Cell class to create cells
            public CellChild(int row, int col)
                : base(row, col)
            {

            }
        }

        /************************************************************************
         *                           Class Members
         ************************************************************************/
        public event PropertyChangedEventHandler cellPorpertyChanged;

        //col,row
        CellChild[,] cells;
        int _rowCount;
        int _colCount;
        public Dictionary<string, string> myDict = new Dictionary<string, string>();


        /************************************************************************
         *                          RowCount property
         ************************************************************************/ 
        public int RowCount
        {
            get
            {
                return _rowCount;
            }
        }

        /**********************************************************************
         *                          ColumnCount property  
         **********************************************************************/
        public int ColumnCount
        {
            get
            {
                return _colCount;
            }
        }

        /*****************************************************************
         *              OnPropertyChanged
         *                 magic happens when event is triggerd 
         *****************************************************************/
        protected void OnPropertyChanged(Cell cell, string t)
        {
            PropertyChangedEventHandler handler = cellPorpertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(t));
            }
        }

        /****************************************************************
         *              handler:
         *                  handels events when they are triggerd              
         ****************************************************************/
        private void handler(object sender, PropertyChangedEventArgs e)
        {
            CellChild cell = sender as CellChild;

            setValue(cell);

            OnPropertyChanged(sender as Cell, e.PropertyName);
        }

        /*************************************************************
         *          setValue:
         *              evaluates expression if cell.Text starts
         *              with "="
         *              if not
         *              sets the value property of the cell
         *              to cell.Text
         *************************************************************/
        private void setValue(CellChild cell)
        {
            string cellText = cell.Text;

            if (cellText.StartsWith("="))
            {
                evaluateExpression(cell);
            }
            else
            {
                //not an expression "write" cellText to value
                cell.Value = cell.Text;
            }
        }


        /***************************************************************************************************
         *                 evalueateExpression:
         *                      finds the cell to copy text from and 
         *                      copys that cells text into current cell
         * *************************************************************************************************/
        private void evaluateExpression(CellChild cell)
        {
            //we already know that text starts with "="

            string text = cell.Text;
            String expression = "";
            expression = expression.ToUpper();           
            expression += text.Substring(1);

            // now need to determine opperation

            if (expression.Length < 2)
            {
                cell.Text = expression;
                cell.Value = "=" + expression;
                return;
            }

            ExpressionTree.Tree expTree = new ExpressionTree.Tree();
            char startChar = expression[0];
            startChar = char.ToUpper(startChar);

            for (int j = 0; j < expression.Length; j++)
            {
                if (expression.ToUpper()[j] >= 'A' && expression.ToUpper()[j] <= 'Z')
                {
                    //variable
                    bool noOp = true;
                    string varName = "";
                    for (int i = j; i < expression.Length && noOp; i++)
                    {

                        switch (expression[i])
                        {
                            case '+':
                            case '-':
                            case '*':
                            case '/':
                            case '(':
                            case ')':
                                j = i;
                                noOp = false;
                                break;
                            default:
                                varName += expression[i];
                                continue;

                        }
                    }

                    //we have a var name to get the value of
                    CellChild variable = getCell(varName.ToUpper());
                    try
                    {
                        expTree.setVariable(variable.Name, double.Parse(variable.Text));
                    }
                    catch (Exception)
                    {
                        //variable is not a double...humm
                        //is it a string

                        cell.Text = variable.Text;

                        //cell.Text = "!INVALID";
                        cell.Value = "=" + expression;
                        return;
                    }
                    
                }
                //not a variable...perhaps a constant
                else if (expression[j] >= '0' && expression[j] <= '9')
                {
                    bool noOp = true;
                    string constant = "";
                    for (int i = j; i < expression.Length && noOp; i++)
                    {
                        switch (expression[i])
                        {
                            case '+':
                            case '-':
                            case '*':
                            case '/':
                            case '(':
                            case ')':
                                j = i;
                                noOp = false;
                                break;
                            default:
                                constant += expression[i];
                                continue;
                        }
                    }
                    
                }
                
            }
            expTree.buildTree(expression.ToUpper());
            try
            {
                cell.Text = expTree.Evaluate().ToString();
            }
            catch (DivideByZeroException e)
            {
                cell.Text = e.Message;
            }

            cell.Value = "=" + expression;

        }

        /**********************************************************************
         *                         doDemo
         *                         runs demo code
         *                         shows that expressions are working
         **********************************************************************/
        public void doDemo()
        {
            Random r = new Random();
            //first fill in column B
            for (int i = 0; i < _rowCount; i++)
            {
                getCell(i, 1).Text = string.Format("This is cell B{0}", i + 1);
            }
            //then do column A
            for (int i = 1; i < _rowCount + 1; i++)
            {
                getCell(i - 1, 0).Text = string.Format("=B{0}", i);
            }
            //now do random stuff and things
            for (int i = 0; i < 50; i++)
            {
                getCell(r.Next(0, 50), r.Next(0, 26)).Text = "Stuff and Things";
            }
            
        }

        /************************************************************************************************
                                Constructor for spreadsheet class       
        *************************************************************************************************/
        public Spreadsheet(int numRows, int numCols)
        {
            _rowCount = numRows;
            _colCount = numCols;
            /***********************************************************************************************
                                    ROWS, COLS!!!!!!!!!!!!!!!!!!!!!!!
            ***********************************************************************************************/
            cells = new CellChild[numRows, numCols];

            for (int i = 0; i < numRows; i++)
            {
                //i = row
                for (int j = 0; j < numCols; j++)
                {
                    //j = col
                    cells[i, j] = new CellChild(i, j);
                    cells[i, j].PropertyChanged += SpreadsheetPropertyChanged;
                }
            }
        }
        /***************************************************************************************
         *                                 SpreadsheetPropertyChanged
         *                                 triggerd when UI changes the text
         *                                 of a cell
         ***************************************************************************************/
        public void SpreadsheetPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            CellChild c = sender as CellChild;
            PropertyChangedEventHandler handler = cellPorpertyChanged;

            if (handler != null && c.Text != null && '=' != c.Text.ElementAt(0))
            {
                handler(c, new PropertyChangedEventArgs(c.Text));
            }
            else if (handler != null && c.Text != null && '=' == c.Text.ElementAt(0))
            {
                // c.Text starts with "="...need to evaluate expression
                evaluateExpression(c);
            }

        }
        /**************************************************************************
         *                          getCell(row, col)
         *                          returns cell at [row, col]
         ***************************************************************************/
        public CellChild getCell(int row, int col)
        {
            if (row < 0 || col < 0)
            {
                return null;
            }
            if (row < _rowCount && col < _colCount)
            {
                
                return cells[row, col];
            }
            else
            {
                return null;
            }
        }
        /************************************************************************************
         *                                  getCell(string name)
         *                                  retuns cell by name
         ************************************************************************************/
        public CellChild getCell(string name)
        {
            int col = name[0] - 65;
            int row = int.Parse(name.Substring(1)) - 1;
            return getCell(row, col);
        }


    }
}
