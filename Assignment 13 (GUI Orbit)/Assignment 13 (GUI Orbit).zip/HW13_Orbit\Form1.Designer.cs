﻿namespace HW13_Orbit
{
    partial class Form1
    {       
        private System.ComponentModel.IContainer components = null;        
       
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.checkBoxCG = new System.Windows.Forms.CheckBox();
            this.checkBoxPlanet = new System.Windows.Forms.CheckBox();
            this.tmrMoving = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(421, 50);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(427, 415);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;            
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseClick);
            // 
            // checkBoxCG
            // 
            this.checkBoxCG.AutoSize = true;
            this.checkBoxCG.Location = new System.Drawing.Point(29, 13);
            this.checkBoxCG.Name = "checkBoxCG";
            this.checkBoxCG.Size = new System.Drawing.Size(93, 17);
            this.checkBoxCG.TabIndex = 1;
            this.checkBoxCG.Text = "Center Gravity";
            this.checkBoxCG.UseVisualStyleBackColor = true;
            // 
            // checkBoxPlanet
            // 
            this.checkBoxPlanet.AutoSize = true;
            this.checkBoxPlanet.Location = new System.Drawing.Point(210, 13);
            this.checkBoxPlanet.Name = "checkBoxPlanet";
            this.checkBoxPlanet.Size = new System.Drawing.Size(56, 17);
            this.checkBoxPlanet.TabIndex = 2;
            this.checkBoxPlanet.Text = "Planet";
            this.checkBoxPlanet.UseVisualStyleBackColor = true;
            // 
            // tmrMoving
            // 
            this.tmrMoving.Enabled = true;
            this.tmrMoving.Tick += new System.EventHandler(this.MovingTick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 555);
            this.Controls.Add(this.checkBoxPlanet);
            this.Controls.Add(this.checkBoxCG);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";            
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);            
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox checkBoxCG;
        private System.Windows.Forms.CheckBox checkBoxPlanet;
        private System.Windows.Forms.Timer tmrMoving;
    }
}

