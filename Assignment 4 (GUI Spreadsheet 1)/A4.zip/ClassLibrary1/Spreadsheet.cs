﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Spreadsheet
{
   public class Spreadsheet 
    {

       public class CellChild : Cell
        {
            public CellChild(int row, int col) : base(row, col)
            {

            }
        }

       public event PropertyChangedEventHandler cellPorpertyChanged;

       //col,row
       CellChild [,] cells;
       int _rowCount;
       int _colCount;

       public int RowCount
       {
           get
           {
               return _rowCount;
           }
       }
       public int ColumnCount
       {
           get
           {
               return _colCount;
           }
       }
       

       protected void OnPropertyChanged(Cell cell, string t)
       {
           PropertyChangedEventHandler handler = cellPorpertyChanged;
           if(handler != null)
           {
               handler(this, new PropertyChangedEventArgs(t));
           }
       }

       private void handler (object sender, PropertyChangedEventArgs e)
       {
           CellChild cell = sender as CellChild;

           setValue(cell);

           OnPropertyChanged(sender as Cell, e.PropertyName);

           


       }



       private void setValue(CellChild cell)
       {
           string cellText = cell.Text;

           if (cellText.StartsWith("="))
           {
               evaluateExpression(cell);

           }
           else
           {
               //not an expression "write" cellText to value

               cell.Value = "cellText";
           }
       }


       private void evaluateExpression(CellChild cell)
       {
           //we already know that text starts with "="

           string text = cell.Text;
           String expression = "";
           for (int i = 1; i < text.Length; i++)
           {
               expression += text.ElementAt(i);
           }
           // now need to determine opperation
           
           //in A4 we only need to pull values from another cell

           //Note for now i will hardcode this part
           char colLetter = expression.ElementAt(0);
           char rowLetter = expression.ElementAt(1);
           char rowLetter2 = '\0';
           if(expression.Length > 2)
           {
               rowLetter2 = expression.ElementAt(2);
           }

           string rowString = rowLetter.ToString() + rowLetter2.ToString();





           int r = -1;
           bool isNum = int.TryParse(rowString, out r);
           bool inRange = false;
           
           colLetter = char.ToUpper(colLetter);

           if(colLetter >= 'A' || colLetter <= 'Z')
           {
               inRange = true;
           }

           if(inRange && isNum)
           {
               //expression is valid

               int col = (int)colLetter - 65;

               cell.Text = getCell(r, col).Text;


           }
           






       }


       public void doDemo()
       {
           Random r = new Random();
           for(int i = 0; i < _rowCount; i++)
           {
               cells[1, i].Text = string.Format("This is cell B{0}", i + 1);
           }

           for (int i = 0; i < _rowCount; i++)
           {
               cells[0, i].Text = string.Format("=B{0}", i);
           }

               for (int i = 0; i < 50; i++)
               {
                   //cells [col, row]
                   cells[r.Next(2, 26), r.Next(0, 50)].Text = "Stuff and Things";
               }
           


       }




        public Spreadsheet(int numRows, int numCols)
        {
            _rowCount = numRows;
            _colCount = numCols;

            cells = new CellChild[numCols, numRows];

            for(int i = 0; i < numCols; i++)
            {
                //i = col
                for(int j = 0; j < numRows; j++)
                {
                    //j = row
                    cells[i, j] = new CellChild(i, j);
                    cells[i, j].PropertyChanged += SpreadsheetPropertyChanged;
                }
            }
        }

       public void SpreadsheetPropertyChanged(object sender, PropertyChangedEventArgs e)
       {
           CellChild c = sender as CellChild;
           PropertyChangedEventHandler handler = cellPorpertyChanged;

           if (handler != null && c.Text != null && '=' != c.Text.ElementAt(0))
           {
               handler(c, new PropertyChangedEventArgs(c.Text));

           }
           else if (handler != null && c.Text != null &&'=' == c.Text.ElementAt(0))
           {
               // c.Text starts with "="...need to evaluate expression

               evaluateExpression(c);




           }

       }

       public Cell getCell(int row, int col)
       {
           if (row <= _rowCount && col <= _colCount)
           {
               //changed here
               return cells[col, row];
           }
           else
           {
               return null;
           }
       }


    }
}
